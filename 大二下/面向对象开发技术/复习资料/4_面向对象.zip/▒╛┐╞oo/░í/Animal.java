public class Animal {
	public void speak(Animal p) {
		System.out.println("Animal Speak!");
	}
}